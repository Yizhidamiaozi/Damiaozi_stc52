#ifndef _FINDWAY_H
#define _FINDWAY_H

void Findway_Init();
void Findway_PID();
void Findway_Deal();


#endif