#ifndef _STEENG_H
#define _STEENG_H

void Com_Init();
void right(uchar SEV);
void lift(uchar SEV);
void Go();
uchar Timer();

#endif